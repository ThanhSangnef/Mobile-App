package com.hotrodoan.model;

public class MyConstants {
    // Replace with your email here:
    public static final String MY_EMAIL = "hoinhom1232023@gmail.com";

    // Replace password!!
    public static final String MY_PASSWORD = "hxudsuuqraijjcef";

    // And receiver!
    public static final String FRIEND_EMAIL = "levankhai0512@gmail.com";
}
