package com.hotrodoan.exception;

public class EquipTypeNotFoundException extends RuntimeException{
    public EquipTypeNotFoundException(String message) {
        super(message);
    }
}
