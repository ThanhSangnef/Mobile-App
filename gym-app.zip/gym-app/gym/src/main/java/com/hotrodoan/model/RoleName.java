package com.hotrodoan.model;

public enum RoleName {
    USER,
    EMPLOYEE,
    ADMIN,
    MANAGER
}
