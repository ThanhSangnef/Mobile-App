import { createBrowserHistory } from "history";

const myHistory = createBrowserHistory({ window });

export default myHistory;